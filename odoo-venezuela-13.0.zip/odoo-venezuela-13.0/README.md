----------------------------------------------

Odoo Venezuela
=================

----------------------------------------------


### Instalar los módulos en este orden:
- territorial_pd
- l10n_ve_base
- l10n_ve_account_payment_fix
- l10n_ve_account_financial_amount
- l10n_ve_account_payment_group
- l10n_ve_account_payment_group_document
- l10n_ve_account_withholding
- l10n_ve_account_withholding_automatic
- l10n_ve_withholding
- l10n_ve_vat_ledger

### Más Información:
- 

### Colaboradores:
- Reydi Hernández <rhe@sinapsys.global>
- Freddy Arraez <far@sinapsys.global>
